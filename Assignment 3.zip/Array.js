var arr = [10,12,3,4,6];
    
    var sum=arr[0]+arr[1]+arr[2]+arr[3]+arr[4];
    console.log(sum);